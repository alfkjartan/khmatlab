This is Panel Version 1

Panel is a replacement for Matlab's subplot
function. For details, see "panel.html".

Author: Ben Mitch
URL: http://tinyurl.com/6mt9yl

TODO:

* adjust margins because x axis labelling takes up more space than y axis labelling
* offer intuitive interface to margins on individual panels (e.g. offer 'p.marginbottom' etc.)
* fully-automatic margins based on what was actually rendered, with respect to "off this edge" alignment
