function [stpfr,mdf]=detectsteps(md,T,lim)
% stpfr=detectsteps(md,T,lim)
% Tries to identify steps in the marker data. md contains only vertical 
% coordinates of markers that may give information about the steps. 
% The start of a step is taken as the first time in a time period that
% a filtered version of the coordinate data goes under a limit which is lim% 
% above the minimum for that period.
% T is an approximate periodlength (in frames).
% stpfr is a cell vector with each cell containing frame numbers for each step, 
% corresponding to the columns in md. Later I may find a smart way to combine
% the information for better detection.

% Kjartan Halvorsen
% 2000-09-29

[nfr,cols]=size(md);

if (nargin<3)
   lim=5;
end

% Use the peridogram to estimate the step frequency.
md=detrend(md);
mdf=fft(md);
nperiods=floor(nfr/T); % The approximate number of periods in the data.
psd=abs(mdf(1:2*nperiods));

maxmdf=max(psd);
peak=find(psd==maxmdf);

T=ceil(nfr/(peak(1)-1));




% Find cut-off frequency, filter data
if (T>10)
   md=filtermdata(md,T,10,8);
end
mdf=md;

   % Do the following: define a delta spike train with time T between 
   % spikes. Move the train until the sum of the product of this signal 
   % and the marker data has a maximum. This corresponds to looking for
   % a maximum of the convolution of the marker data and the spike train
   % near the middle of the convolution series.

train=zeros(nfr,1);
train(1:T:nfr)=1;

np=floor(nfr/T);

stpfr=cell(cols);


for col=1:cols

   try
      mdc=md(:,col);
      cmt=conv(mdc,train);
      starti=nfr;
      ci=starti;
      while(cmt(ci) < cmt(ci-1) | cmt(ci) < cmt(ci+1))
         if (cmt(ci+1)>=cmt(ci))
            ci=ci+1;
         else
             ci=ci-1;
         end
         if (ci<2 | ci>length(cmt)-2)
            error('Maximum of convolution found at ends of sequence.');
         end
      end
      offset=ci-nfr;
      if (offset>=0)
         peaks=find(train)+offset;
      else
         peaks=find(train)+(T-offset);
      end
      if (peaks(1)>T*3/4) peaks=[1;peaks]; end
      peaks(find(peaks>nfr))=[];
      if (peaks(length(peaks))<(nfr-T*3/4)) peaks=[peaks; nfr]; end

      % Now the peaks are found, compute the minimum for each period. Then
      % find the frame where the marker coordinate first drops below lim%
      % of the minimum.
   
      np=length(peaks)


      mdcfst=mdc(peaks(1):peaks(2));
      mdclst=mdc(peaks(np-1):peaks(np));
      mdc=reshape(mdc(peaks(2):peaks(np-1)-1),T,np-3);
   
      thrfst=min(mdcfst) + lim/100*(max(mdcfst)-min(mdcfst));
      Dfst=((mdcfst-ones(size(mdcfst))*thrfst) < 0);   
      % Ones where coordinate is below thr
   
      thrlst=min(mdclst) + lim/100*(max(mdclst)-min(mdclst));
      Dlst=((mdclst-ones(size(mdclst))*thrlst) < 0);   
      % Ones where coordinate is below thr
   
      thr=min(mdc) + lim/100*(max(mdc)-min(mdc));
      D=((mdc-kron(ones(T,1),thr)) < 0);   
      % Ones where coordinate is below thr
   
      % Find the index of the first 1 in each column.
      stpfrc=zeros(np-1,1);

      ffst=find(Dfst);
      stpfrc(1)=ffst(1);
      flst=find(Dlst);
      stpfrc(np-1)=(np-2)*T+flst(1);

      for p=2:np-2
         fi=find(D(:,p-1));
         stpfrc(p,col)=peaks(1)+(p-1)*T+fi(1);
      end
   
      stpfr{col}=stpfrc;

   catch
      uiwait(warndlg(['Unable to find enough peaks in the data.', ...
                      'Try to detect the steps manually']));
      stpfr={};
      return
   end
      
end   
   


