function detectrbfcns(h,fstr)
% Collection of simple functions that handle the list of rigid segments.

% Kjartan Halvorsen
% 2000-10-09

% get handles
sgmlh=findobj(h,'Tag','detectrbsgmlist');
mlh=findobj(h,'Tag','detectrbmlist');

sgms=get(sgmlh,'UserData');
sgmstr=get(sgmlh,'String');
markerstr=get(mlh,'UserData');

if (strcmp(fstr,'remove'))
   k=get(sgmlh,'Value');
   sgms{k}
   sgms=removecell(sgms,k);
   sgmstr=removecell(sgmstr,k);
   set(sgmlh,'UserData',sgms);
   set(sgmlh,'String',sgmstr);
   set(sgmlh,'Value',1);
   updatesgmlist(h);

elseif (strcmp(fstr,'done'))
   tsvpph=get(h,'UserData');
   tppdata=get(tsvpph,'UserData');
   if (~isempty(sgms))
      nsgms=cell(size(sgms));
      for k=1:length(sgms) 
         nsgms{k}=markerstr(sgms{k});
      end
      rbdata.sgms=nsgms;
      rbd.sgmnames=sgmstr;
      tppdata.rbdata=rbdata;
      set(tsvpph,'UserData',tppdata);
      rblh=findobj(tsvpph,'Tag','rblist');
      rbph=findobj(tsvpph,'Tag','rbpopup');
      set(rblh,'String',sgmstr);
      set(rblh,'Value',length(sgmstr));
      % rbmotion={'Euler angles','Helical Axis'};
      rbmotion={'Helical Axis'};
      set(rbph,'String',rbmotion);
      set(rbph,'Value',1);
     
   end
   close
end
