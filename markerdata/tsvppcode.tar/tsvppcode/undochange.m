function undochange(h)
% This function swaps the tsvdata with the value stored under
% undomenu's UserData attribute.

% Kjartan Halvorsen
% 2000-10-13

% Get handles
uh=findobj(h,'Tag','undomenu');

olddata=get(uh,'UserData');

if (~isempty(olddata))
   newdata=get(h,'UserData');
   set(h,'UserData',olddata);
   set(uh,'UserData',newdata);
   plotmarkers(h);
end

