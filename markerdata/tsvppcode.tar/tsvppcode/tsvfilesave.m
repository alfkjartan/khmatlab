function tsvfilesave(h)
% Saves marker data to a tsv file.

% Kjartan Halvorsen
% 2000-09-10

% Obsolete. Open file identifier in calling function, then call tsvfilewrite.


tsvdata=get(h,'UserData');

[fname,pthname]=uiputfile('*.tsv','Save tsv file');
fid=fopen([pthname,fname],'w');
writeheader(fid,tsvdata.tsvattributes);
writedata(fid,tsvdata.markerdata);
fclose(fid);

function writeheader(fid,attr)
  % Write the header part of the tsv file.
  [as,n]=size(attr);
  for at=1:as
    fprintf(fid,'%s\t',attr{at,1});
    if (ischar(attr{at,2}))
      fprintf(fid,'%s\n',attr{at,2});
    elseif (iscell(attr{at,2}))
      nm=length(attr{at,2});
      for m=1:nm-1
        fprintf(fid,'%s\t',attr{at,2}{m});
      end
      fprintf(fid,'%s\n',attr{at,2}{nm});
    else 
      fprintf(fid,'\n');
    end      
  end

function writedata(fid,mdata);
% write the data part
  [m,n]=size(mdata);
  format='';
  for col=1:n-1
    format=[format,'%f\t'];
  end
  format=[format,'%f\n'];

  fprintf(fid,format,mdata');
