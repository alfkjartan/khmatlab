function openeditsgmgui(h,fstr)
% Launches the openeditsgmgui dialog. If fstr='edit', the current 
% selected segment name and markers appear in the appropriate
% places in the gui.

% Kjartan Halvorsen
% 2000-10-09

edith=editsgmgui;

% Get handles 
nameh=findobj(edith,'Tag','editsgmnametxt');
mlh=findobj(edith,'Tag','editsgmlist');
btnh=findobj(edith,'Tag','editsgmdonebtn');
sgmlh=findobj(h,'Tag','detectrbsgmlist');
rbmlh=findobj(h,'Tag','detectrbmlist');

markers=get(rbmlh,'UserData');
set(mlh,'String',markers);

sgms=get(sgmlh,'UserData');

if (strcmp(fstr,'edit')) % insert name of segment and select markers
   sgmstr=get(sgmlh,'String');
   sgmid=get(sgmlh,'Value');
   if (~isempty(sgmstr))
      set(nameh,'String',sgmstr{sgmid});
      set(mlh,'Value',sgms{sgmid});
   end
   set(edith,'UserData',h); % Necessary for editsgmdlg to reference detectrbdlg
elseif (strcmp(fstr,'add')) % Add the segment first, then call editsgmgui
   sgmid=length(sgms)+1;
   sgms{sgmid}=1:length(markers);
   sgmstr=get(sgmlh,'String');
   sgmstr{sgmid}=['segment',int2str(sgmid)];
   set(sgmlh,'UserData',sgms);
   set(sgmlh,'String',sgmstr);
   set(sgmlh,'Value',sgmid);
   set(nameh,'String',sgmstr{sgmid});
   set(mlh,'Value',(1:length(markers)));
   set(edith,'UserData',h); % Necessary for editsgmdlg to reference detectrbdlg
end

