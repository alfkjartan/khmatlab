function filterthedata(h,all)
% Filters the data with the cut-off frequency and filter order specified
% by the user.

% Kjartan Halvorsen
% 2000-09-20

% Get handlers
cftxth=findobj(h,'Tag','cutofftxt');
otxth=findobj(h,'Tag','ordertxt');

preproch=get(h,'UserData');
stath=findobj(preproch,'Tag','statusbar');
listh=findobj(preproch,'Tag','markerlist');

cutoffstr=get(cftxth,'String');
if (isempty(cutoffstr))
   set(stath,'String','You need to specify a cut-off frequency.');
   return
end
try 
   cof=str2num(cutoffstr);
catch
   set(stath,'String','Did not recognize the cutoff frequency.');
   return
end

orderstr=get(otxth,'String');
if (isempty(orderstr))
   set(stath,'String','You need to specify a filter order.');
   return
end
try 
   fo=str2num(orderstr);
catch
   set(stath,'String','Did not recognize the filter order.');
   return
end

tsvdata=get(preproch,'UserData');
samplefreqstr=getvalue(tsvdata.tsvattributes,'FREQUENCY');
samplefreq=str2num(samplefreqstr);

% More checking
if (fo<2)
   set(stath,'String','The filter order must be >1.');
   return
end
   
if (cof<(1/samplefreq) | cof>samplefreq/2)
   set(stath,'String',...
   ['OBS: ',num2str(1/samplefreq),' < cutoff frequency < ',...
	  num2str(samplefreq/2)]);
   return 
end
   

if (all) % Filter all the data 
   nmd=filtermdata(tsvdata.markerdata,samplefreq,cof,fo);
else % Filter only selected markers
   sel=get(listh,'Value'); % a vector containing the selected rows.
   ind=[];
   for v=sel
      ind=[ind 3*(v-1)+1:3*v];
   end
   nmd=tsvdata.markerdata;
   nmd(:,ind)=filtermdata(nmd(:,ind),samplefreq,cof,fo);
end

% Store old version of tsvdata in undomenu's UserData attribute
undoh=findobj(preproch,'Tag','undomenu');
set(undoh,'UserData',tsvdata);

tsvdata.markerdata=nmd;
set(preproch,'UserData',tsvdata);

plotmarkers(preproch); % Plot the filtered data.

close(h);
