function plotmarkers(h)
% This function is called when the user changes the list.

% Kjartan Halvorsen
% 2000-09-19

% Get handlers
listh=findobj(h,'Tag','markerlist');
xh=findobj(h,'Tag','xcheck');
yh=findobj(h,'Tag','ycheck');
zh=findobj(h,'Tag','zcheck');

% Find which markers to plot
val=get(listh,'Value'); % a vector containing the selected rows.

% Find which coordinates to plot
xc=get(xh,'Value');
yc=get(yh,'Value');
zc=get(zh,'Value');

ind=[];
for v=val
   if (xc)ind=[ind 3*(v-1)+1]; end
   if (yc)ind=[ind 3*(v-1)+2]; end
   if (zc)ind=[ind 3*(v-1)+3]; end
end


% The data
tsvd=get(h,'UserData');
md=tsvd.markerdata;


figure(h)
plot(md(:,ind));
xlabel('Frame #');
