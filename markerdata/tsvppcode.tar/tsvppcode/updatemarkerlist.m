function updatemarkerlist(h,attr,val)
% Updates the list of markers.
% h is a handle to the marker list, attr is the tsv attributes
% and val is the marker(s) selected.

mnames=getvalue(attr,'MARKER_NAMES');
set(h,'String',mnames);
set(h,'Value',val);
