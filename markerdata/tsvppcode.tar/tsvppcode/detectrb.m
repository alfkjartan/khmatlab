function sgms=detectrb(varargin)
% sgms=detectrb(md,tol)
% Detects possible rigid bodies in the marker data. A set of markers are 
% considered to belong to the same rigid body if the distance between them
% varies much less than the movement of the markers.
%
% md is the marker data and tol is the decision threshold. A lower 
% value of tol means that less variance of the inter-marker distance is
% tolerated in order to consider the two markers as belonging to the same
% rigid body.

% Kjartan Halvorsen
% 2000-09-28

if (nargin==1)
   md=varargin{1};
   tol=1e-2;
else
   md=varargin{1};
   tol=varargin{2};
end

[rs,cs]=size(md);
marks=cs/3;

% Remove the motion of the centroid
nmd=reshape(md,rs*3,marks);
cpth=(mean(nmd'))';
nmd=nmd-kron(ones(1,marks),cpth);

% Working with the marker data in the form where the x,y, and z coordinates
% are stacked on top of each other. Each marker path is a single column 
% vector

% Compute the variance of each marker path.
mdvar=var(nmd);

% Compute the variance of the distance between each marker.
% Form a symmetric matrix, where the (i,j) element is the variance
% of the distance between marker i and j. Normalize each element by 
% dividing with the sum of the variance of markers i and j.

D=zeros(marks,marks);

for i=1:marks
   for j=i+1:marks
      D(i,j)=var(nmd(:,i)-nmd(:,j))/(mdvar(i)+mdvar(j));
      D(j,i)=D(i,j);
   end
end

DD=(D<tol); % 1s where two markers are keeping their distance. zeros 
            % elsewhere.
DD=DD-eye(marks);

% Read off the rigid bodies.
sgms=idrbs(DD);


%Private function
function rbs=idrbs(D)
   % The function will go through the sorted matrix D, and identify which 
   % markers belong to the same rigid body. The result is permuted according
   % to the permutation matrix P, so that the marker indices are the same as 
   % the original.
   % The function works in a divide-and-conquer fashion with recursive 
   % calls. 

   [nm,nm]=size(D);

    if (nm==2) 
      if (sum(D)) 
         rbs={[1 2]};
      else
         rbs={};
      end
    else

      % When a connection is assigned to a rigid body, it is also set to 
      % zero. Hence we'll repeat the algorithm for resolving the connections
      % until there are no connections left. 

      rbs=cell(0);
      
      while (max(max(D))) 
        % Find the most connected marker, and sort the connection matrix
        [DS,P]=sortconnections(D);

        mi=find(DS(1,2:nm)) + 1
  
        if (length(mi)==0)
           crbs={};
        elseif (length(mi)==1)
           crbs={[mi-1]};
        else 
           crbs=idrbs(DS(mi,mi)); % The recursive call
        end
 
        for rbi=1:length(crbs)
           rb=crbs{rbi}; 
           rb=[1 rb+1];
           for mmi=1:length(rb)
              rb(mmi)=find(P(:,rb(mmi)));
           end
           crbs{rbi}=rb;
        end

        rbs={rbs{:},crbs{:}};

        DS([1 mi],[1 mi])=0;
        D=P'*DS*P;
      end
   end


function [DS,P]=sortconnections(D)
   % Searches for the most connected marker. Puts this in the first
   % position, and then sorts the other marker so that those connected
   % with the first are in the first positions, 2 and up.

   [nm,nm]=size(D);

   connections=sum(D);
   mc=find(connections==max(connections))

   P=pivot(1,mc(1),nm);
   DS=P*D*P';

   theones=find(DS(1,:));
   thezeros=find(~DS(1,:));
   thezeros(1)=[]; % Will always be the diagonal element
   while(min(thezeros)<max(theones))
      PP=pivot(min(thezeros),max(theones),nm);
      P=PP*P;
      DS=PP*DS*PP';
      theones=find(DS(1,:));
      thezeros=find(~DS(1,:));
      thezeros(1)=[]; % Will always be the diagonal element
   end


function P=pivot(i,j,n)
   % Returns a pivot matrix that exchanges rows i and j and columns i and j

   P=eye(n);
   P(i,i)=0;
   P(j,j)=0;
   P(i,j)=1;
   P(j,i)=1;

   

 
