function opendetectrbgui(h)
% Simple function that launches the detectrb gui, and sets the
% UserData attribute of the detectrb figure to the handle h.
% This way, the functions of detectrb gui can easily reference
% the tsvpreprocgui, and its important tsvdata (UserData) attribute.

% Kjartan Halvorsen
% 2000-10-13

fh=detectrbgui;
set(fh,'UserData',h);
