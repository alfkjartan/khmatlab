function updatesgmlist(h)
% This function is called when the list of detected segments is changed.

% Kjartan Halvorsen
% 2000-10-09

% get handles
sgmlh=findobj(h,'Tag','detectrbsgmlist');
mlh=findobj(h,'Tag','detectrbmlist');

val=get(sgmlh,'Value');
sgms=get(sgmlh,'UserData');
markerstr=get(mlh,'UserData');
length(sgms)
length(markerstr)

if (~isempty(sgms))
   set(mlh,'String',{markerstr{sgms{val}}});
end
