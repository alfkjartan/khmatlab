function tsvppfcns(h,action)
% Callback functions for the tsvppgui.
%

% Kjartan Halvorsen
% 2001-01-22

switch lower(action)
   case 'openfile'

      [fname,pthname]=uigetfile('*.TSV','Open tsv file');
      if (~fname)
         return
      end

      cd(pthname);

      fid=fopen([pthname,fname]);
      [attributes,mdata]=read3dtsv(fid);
      fclose(fid);

      tsvdata.tsvattributes=attributes;
      tsvdata.markerdata=mdata;
      set(h,'UserData',tsvdata);

      mnames=getvalue(attributes,'MARKER_NAMES');

      % Set the scroll list with the names of the markers
      listh=findobj(h,'Tag','markerlist');
      set(listh,'String',mnames);
      set(listh,'Value',1:length(mnames));
      % Display the data series
      axesh=findobj(h,'Tag','theaxes');
      plot(mdata)
      xlabel('Frame #')

   case 'savefile'

      tsvdata=get(h,'UserData');

      if isempty(tsvdata)
         return
      end

      [fname,pthname]=uiputfile('*.tsv','Save tsv file');
      if (~fname)
         return
      end

      fid=fopen([pthname,fname],'w');
      %writeheader(fid,tsvdata.tsvattributes);
      writedata(fid,tsvdata.markerdata);
      fclose(fid);

   case 'close'
      close(h)

      
   case 'undo'

      uh=findobj(h,'Tag','undomenu');

      olddata=get(uh,'UserData');

      if (~isempty(olddata))
         newdata=get(h,'UserData');
         set(h,'UserData',olddata);
         set(uh,'UserData',newdata);
         tsvppfcns(h,'plotmarkers');
      end


   case 'filter'

      % Ask the user wether to use a simple moving average, or a 
      % Butterworth filter.
      filtertype=questdlg('What type of filter?','The filter',...
                          'Butterworth','Moving average','Butterworth');

      switch filtertype
         case 'Butterworth'
            % Find the sample frequency of the data
            tsvd=get(h,'UserData');
            try
               attr=tsvd.tsvattributes;
               samplefreq=str2num(getvalue(attr,'FREQUENCY'));
            catch
               samplefreq=240; % Assume 240 Hz
            end

            % Launch a dialog so the user can enter information.
            prompt={'Enter the cut-off frequency (Hz):',...
                    'Enter the filter order:'};
            def={int2str(samplefreq/6),'4'};
            title=['Filter parameters. Sample frequency is ',...
                   int2str(samplefreq),' Hz.'];
            
            filterpar=inputdlg(prompt,title,1,def);

            if ~(isempty(filterpar{1}) & isempty(filterpar{2}))
%               try
                  cof=str2num(filterpar{1});  
                  fo=str2num(filterpar{2});  
               
                  % Check that the values are valid.
                  if (fo<2) return; end
                  if (cof<(1/samplefreq) | cof>(samplefreq/2)) return; end
		  
                  nmd=filtermdata(tsvd.markerdata,samplefreq,cof,fo);

                  % Store old version of tsvdata in undomenu's 
                  % UserData attribute
                  undoh=findobj(h,'Tag','undomenu');
                  set(undoh,'UserData',tsvd);

                  tsvd.markerdata=nmd;
                  set(h,'UserData',tsvd);

                  tsvppfcns(h,'plotmarkers'); % Plot the filtered data.
%               end % try
            end % if

         case 'Moving average'
            % Ask the user for the number of lags to use
            window=inputdlg('Enter the window size: ', 'Window size',1,{'5'});

            if ~(isempty(window))
               tsvd=get(h,'UserData');
%               try
                  wl=str2num(window{1});

                  % Check that the values are valid.
                  if (wl<2) return; end

                  nmd=khamovavg(tsvd.markerdata,wl);

                  % Store old version of tsvdata in undomenu's 
                  % UserData attribute
                  undoh=findobj(h,'Tag','undomenu');
                  set(undoh,'UserData',tsvd);

                  tsvd.markerdata=nmd;
                  set(h,'UserData',tsvd);

                  tsvppfcns(h,'plotmarkers'); % Plot the filtered data.
%               end % try
            end % if

         end % switch
               
   case 'updateplot'

      tsvppfcns(h,'plotmarkers');


   case 'plotmarkers'
      
      % Get handlers
      listh=findobj(h,'Tag','markerlist');
      xh=findobj(h,'Tag','xcheck');
      yh=findobj(h,'Tag','ycheck');
      zh=findobj(h,'Tag','zcheck');

      % Find which markers to plot
      val=get(listh,'Value'); % a vector containing the selected rows.

      % Find which coordinates to plot
      xc=get(xh,'Value');
      yc=get(yh,'Value');
      zc=get(zh,'Value');

      ind=[];
      for v=val
         if (xc) ind=[ind 3*(v-1)+1]; end
         if (yc) ind=[ind 3*(v-1)+2]; end
         if (zc) ind=[ind 3*(v-1)+3]; end
      end

      tsvd=get(h,'UserData');
      md=tsvd.markerdata;

      if (~isempty(ind))
         figure(h)
         plot(md(:,ind));
         xlabel('Frame #');
      end

   case 'detectsteps'

%      try 
         tsvdata=get(h,'UserData');
         markernames=getvalue(tsvdata.tsvattributes,'MARKER_NAMES');
         Fs=getvalue(tsvdata.tsvattributes,'FREQUENCY');

         % Find the time series to use.
         [md,T]=detectstepsprep(tsvdata.markerdata,markernames,Fs);

         % The next function does the job of detecting the steps.
         [stpfr,mdf]=detectsteps(md,T);
         stpfr=stpfr{1};

         % Next plot the data and the steps, and let the user move the steps 
         % that seem misplaced.

         stepfr=detectstepsplot(stepfr,mdf);
%      end


      tsvdata.tsvattributes=putvalue(tsvdata.tsvattributes,'CYCLES',stepfr);

      set(h,'UserData',tsvdata);

      msgbox(['Steps start at : ', sprintf('%d  ',stepfr)])

   case 'detectrb'
      try 
	  fig=detectrbgui;
	  set(fig,'UserData',h);
      end
 
   case 'clipdata'
      tsvd=get(h,'UserData');
      nmd=clipmdata(tsvd.markerdata);
      
      % Store old version of tsvdata in undomenu's 
      % UserData attribute
      undoh=findobj(h,'Tag','undomenu');
      set(undoh,'UserData',tsvd);

      tsvd.markerdata=nmd;
      set(h,'UserData',tsvd);

      tsvppfcns(h,'plotmarkers'); % Plot the truncated data.

   case 'zoom'
      tsvd=get(h,'UserData');
      
      % Get handlers
      listh=findobj(h,'Tag','markerlist');
      xh=findobj(h,'Tag','xcheck');
      yh=findobj(h,'Tag','ycheck');
      zh=findobj(h,'Tag','zcheck');

      % Find which markers to plot
      val=get(listh,'Value'); % a vector containing the selected rows.

      % Find which coordinates to plot
      xc=get(xh,'Value');
      yc=get(yh,'Value');
      zc=get(zh,'Value');

      ind=[];
      for v=val
         if (xc) ind=[ind 3*(v-1)+1]; end
         if (yc) ind=[ind 3*(v-1)+2]; end
         if (zc) ind=[ind 3*(v-1)+3]; end
      end

      figure(2)
      clf
      plot(tsvd.markerdata(:,ind));
%      khazoomsave

end % switch
