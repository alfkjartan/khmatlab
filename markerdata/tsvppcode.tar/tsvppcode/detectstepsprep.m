function [md,T]=detectstepsprep(mdata,markernames,Fs);
%
% [md,T]=detectstepsprep(tsvdata,markernames);
%
% Input
%    mdata        ->  Marker data. Matrix.
%    markernames  ->  Cell array of marker names.
%    Fs           ->  Sampling frequency.
     
% Returns the time series, and the approximate period to be used in the 
% automatic detection of cycles (steps). 

% Kjartan Halvorsen
% 2001-02-22
   
okm=0;
okc=0;
okp=0;

while (~(okm & okc & okp))

     nl=sprintf('\n');

      prompt=sprintf('%s\n','Choose the marker to use in the step detection.');
      for i=1:length(markernames)
         prompt=[prompt, int2str(i), '   ',markernames{i},nl];
      end

      prompt2=['Enter which coordinates to use. ',...
               '(x, y or z):'];

      prompt3=['Enter the approximate stride length (in seconds)'];

      answer=inputdlg({prompt,prompt2,prompt3},'Step detection');

      if (isempty(answer))
          uiwait(warndlg('The analysis has been cancelled'));
	  md=[];
          
      else

         % Parse the answer

         [marker,rest]=strtok(answer{1},',;');
         try 
            marker=str2num(marker);
            marker=fix(marker);
            if (marker<0 | marker>length(markernames))
               error('Marker index out of range');
            end
            okm=1;
         catch
            uiwait(msgbox(['Wrong input: ',lasterr,'  Try again.'],...
                           'Oops'))
         end

         ntimeseries=0; 
	 % Integer for storing the number of timeseries to be used.

	 [coord,rest]=strtok(answer{2},' ,;');
	 try 
	    switch coord(1)
	        case 'x'
                   coordind=1;
                   ntimeseries=ntimeseries+1;
	        case 'y'
                   coordind=2;
		   ntimeseries=ntimeseries+1;
                case 'z'
                   coordind=3;
                   ntimeseries=ntimeseries+1;
		otherwise
                   error(['Unrecognized symbol: ',coord(1)])
             end
	     okc=1;
         catch
            uiwait(msgbox(['Wrong input: ',lasterr,'  Try again.'],'Oops'))
         end

         try 
            period=str2num(answer{3});
            okp=1;
         catch
            uiwait(msgbox(['Wrong input: ',lasterr,'  Try again.'],'Oops'))
         end

      end
end


      T=Fs*period;
      
      % Pick out the correct time series.
      md=mdata(:,(marker-1)*3+coordind);
