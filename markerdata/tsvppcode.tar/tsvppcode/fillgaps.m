function nmd=fillgaps(md)
% nmd=fillgaps(md)
% Interpolates to fill the gaps in the columns of md.

% Kjartan Halvorsen
% 2000-09-19

[rs,cs]=size(md);

nmd=md;

for col=1:cs
   ind=find(md(:,col)==0);
   notind=setdiff((1:rs),ind);
   nmd(ind,col)=interp1(notind,md(notind,col),ind,'spline');
end

   
