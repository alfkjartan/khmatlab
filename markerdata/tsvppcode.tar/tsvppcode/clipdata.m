function clipdata(h)
% This function lets the user choose to clip the data series. 
% Basically, the user chooses two time frames by clicking in the
% plot. After the second click, the data between the two time frames is
% extracted, the rest is discarded, and the data is plotted. 
% The user may undo by hitting 'Escape'.

% Kjartan Halvorsen
% 2000-10-13

% Get handles

   sbh=findobj(h,'Tag','statusbar');
   undoh=findobj(h,'Tag','undomenu');

   set(sbh,'String','Select a range by clicking twice in the plot');

[x,y]=ginput(2);

if (length(x==2))
   tsvdata=get(h,'UserData')
   set(undoh,'UserData',tsvdata);
   md=tsvdata.markerdata;
   nmd=md(floor(min(x)):ceil(max(x)),:);
   tsvdata.markerdata=nmd;
   set(h,'UserData',tsvdata);
   plotmarkers(h);
end

