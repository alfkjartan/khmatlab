function ok=tsvfilewrite(attr,mdata,fid)
% Saves marker data to a tsv file.

% Kjartan Halvorsen
% 2001-01-22

% Write the header part of the tsv file.

k=keys(attr);
for at=1:length(k)
   fprintf(fid,'%s\t',k{at});

   val=getvalue(attr,k{at});
   if (ischar(val))
      fprintf(fid,'%s\n',val);
   elseif (iscell(val))
      vl=length(val);
      for m=1:vl-1
         if(ischar(val{m}))
            fprintf(fid,'%s\t',val{m});
         else
            fprintf(fid,'%f\t',val{m});
         end
      end
      if(ischar(val{vl}))
         fprintf(fid,'%s\n',val{vl});
      else
         fprintf(fid,'%f\n',val{vl});
      end
   else
      fprintf(fid,'%f\n',val);
   end      
end

% write the data part
  [m,n]=size(mdata);
  format='';
  for col=1:n-1
    format=[format,'%f\t'];
  end
  format=[format,'%f\n'];

  fprintf(fid,format,mdata');
