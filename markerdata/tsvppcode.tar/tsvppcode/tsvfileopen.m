function tsvfileopen(h)
% Tries to open a .tsv file specified by the user from a standard 
% fileopen dialog.

% Kjartan Halvorsen
% 2000-09-08

[fname,pthname]=uigetfile('*.tsv','Open tsv file');
if (~fname)
  return
end

fid=fopen([pthname,fname]);
[attributes,mdata]=stripheader(fid);
fclose(fid);

tsvdata.tsvattributes=attributes;
tsvdata.markerdata=mdata;
set(h,'UserData',tsvdata);

mnames=getvalue(attributes,'MARKER_NAMES');

% Set the scroll list with the names of the markers
listh=findobj(h,'Tag','markerlist');
set(listh,'String',mnames);
set(listh,'Value',1:length(mnames));
% Display the data series
axesh=findobj(h,'Tag','theaxes');
plot(mdata)
xlabel('Frame #')

function [attr,d]=stripheader(fid)
  % Reads the header into a struct head. Then reads the tab spaced values
  % into the matrix d.

  % Check to see if there is a header
  line='';
  emptylines=-1;
  while (isempty(line) & ~feof(fid))  
    line=fgetl(fid);
    emptylines=emptylines+1;
  end
  
  if (feof(fid))
    error('Empty file.')
  end

  if (line(1) < '0' | line(1) > '9') % first line does not start with number
    % Read the header containing the attribute and value pairs
    attr=cell(1,2);
    acnt=0;
    [attrname,attrval]=strtok(line);
    while ((attrname(1) < '0' | attrname(1) > '9') & ~feof(fid))
      acnt=acnt+1;
      attr{acnt,1}=attrname;
      attr{acnt,2}=attrval;
      line=fgetl(fid);
      [attrname,attrval]=strtok(line); % Read the attribut name and value
    end

    % Parse the marker names to construct a cell array with a string for each
    % marker
    nframes=sscanf(getvalue(attr,'NO_OF_FRAMES'),'%d'); 
    nmarkers=sscanf(getvalue(attr,'NO_OF_MARKERS'),'%d'); 
    mnstr=getvalue(attr,'MARKER_NAMES');
  
    mnames=cell(nmarkers,1);
    for m=1:nmarkers
      [mnames{m},mnstr]=strtok(mnstr);
    end
    attr=putvalue(attr,'MARKER_NAMES',mnames); 
    % Overwriting the attribute value with the new cell array.

    % Reading the rest of the tsv data

    % Rewind and read through to the start of the data values.
    frewind(fid);
    for l=1:(acnt+emptylines)
       fgetl(fid);
    end
      
    d=fscanf(fid,'%f');
    try	
      d=reshape(d,nmarkers*3,nframes);
    catch
      error('Data does not correspond to header information.')
    end
    d=d';

  else  % The file contains only data, no header.

    % check the line for the number of columns.
    firstrow=sscanf(line,'%f');
    cols=length(firstrow);

    frewind(fid);
    for l=1:emptylines
       fgetl(fid);
    end
  
    d=fscanf(fid,'%f');
    try	
      d=reshape(d,cols,length(d)/cols);
    catch
      error('Unable to read tsv data. Rows are not equally long.')
    end

    d=d';

  end
