function nm=khamovavg(m,wl)
% nm=khamovavg(m,wl)
% Simple moving average along columns. wl is the windowlength.

% Kjartan Halvorsen
% 2001-01-23

nm=zeros(size(m));

lead=floor(wl/2);
lag=1+floor(wl/2);
   
for idx = 1:lead
   nm(idx,:) = mean(m(1:idx,:));
end

for idx = lead+1:length(m(:,1))-lag,
   nm(idx,:) = mean(m(idx-lead:idx+lag,:));
end

for idx = length(m(:,1))-lag+1:length(m(:,1)),
   nm(idx,:) = mean(m(length(m(:,1))-lag+1:end));
end


