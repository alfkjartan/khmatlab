function editsgmfcns(h,fstr)
% Collection of simple functions that handle the editing of a segment
% Called from the editsgmgui dialog.

% Kjartan Halvorsen
% 2000-10-09

% get handles
nameh=findobj(h,'Tag','editsgmnametxt');
mlh=findobj(h,'Tag','editsgmlist');
btnh=findobj(h,'Tag','editsgmdonebtn');

drbh=get(h,'UserData'); % handle to the detectrbgui.
sgmlh=findobj(drbh,'Tag','detectrbsgmlist');

markers=get(mlh,'String');

if (strcmp(fstr,'done'))
   sgmid=get(sgmlh,'Value');
   markids=get(mlh,'Value');
   name=get(nameh,'String');
   if (~isempty(markids) & ~isempty(name))
      sgms=get(sgmlh,'UserData');
      sgmstr=get(sgmlh,'String');
      sgms{sgmid}=markids;
      sgmstr{sgmid}=name;
      set(sgmlh,'UserData',sgms);
      set(sgmlh,'String',sgmstr);
      close(h);
      updatesgmlist(drbh);
   end
end
