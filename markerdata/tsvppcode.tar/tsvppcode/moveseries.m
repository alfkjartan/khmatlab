function [newmdata,newattr]=moveseries(mark,dir,mdata,attr)
% [newmdata,newmnames,newattr]=moveseries(mark,dir,mdata,attr)
% Changes the order of the columns with marker data by moving the 
% data of the given marker one step in the given direction. 
%
% Input
%    mark      ->   the name of the marker (string)
%    dir       ->   the direction (string). 'left' and 'up' are equivalent,
%                    as are 'right' and 'down'.
%    mdata     ->   the marker data (doubles, matrix)
%    attr      ->   the attributes (string, cell array)
% Output
%    Updated versions of the corresponding inputs.

% Kjartan Halvorsen
% 2000-09-12

mnames=getvalue(attr,'MARKER_NAMES');
nm=length(mnames);
ind=0;
for k=1:nm
  if (strcmp(mnames{k},mark))
    ind=k;
  end
end

if (ind==0)
  warning(['The marker ',mark,' was not found.'])
  newmdata=mdata;
  newattr=attr;
end
  
if (strcmp(dir,'left') | strcmp(dir,'up'))
  if (ind>1)
    newmdata=[mdata(:,1:3*(ind-2)) mdata(:,3*(ind-1)+1:3*ind) ...
              mdata(:,3*(ind-2)+1:3*(ind-1)) mdata(:,3*ind+1:3*nm)];
    newnames={mnames{1:(ind-2)} mnames{ind} mnames{ind-1} mnames{(ind+1):nm}};
    newattr=putvalue(attr,'MARKER_NAMES',newnames);
  end
elseif (strcmp(dir,'right') | strcmp(dir,'down'))
   if (ind<nm)
    newmdata=[mdata(:,1:3*(ind-1)) mdata(:,3*ind+1:3*(ind+1)) ...
              mdata(:,3*(ind-1)+1:3*ind) mdata(:,3*(ind+1)+1:3*nm)];
    newnames={mnames{1:(ind-1)} mnames{ind+1} mnames{ind} mnames{(ind+2):nm}};
    newattr=putvalue(attr,'MARKER_NAMES',newnames);
  end
else
  warning(['Value ',dir,' of argument dir is not recognized.'])
  newmdata=mdata;
  newattr=attr;
end

