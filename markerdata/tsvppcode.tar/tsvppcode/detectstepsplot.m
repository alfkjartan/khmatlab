function  stepfr=detectstepsplot(stpfr,mdf);
%
%  stepfr=detectstepsplot(stepfr,mdf);
% 
% Plots the time series mdf and over lies the beginning of the steps as 
% vertical lines. The user is then asked to modify the set of lines so 
% as to truly correspond to the beginning (and end) of each cycle.

% Kjartan Halvorsen
% 2001-02-22


      fig=figure;

      plot(mdf);
      hold on
      if (~isempty(stpfr))
         steplines=plot([stpfr';stpfr'],...
           [min(min(mdf))*ones(1,length(stpfr))
            max(max(mdf))*ones(1,length(stpfr))],...
              'g','EraseMode','xor');
         set(steplines,'ZData',[1;1]);
      end
   
      movelinex(fig);
      
      khazoomsafe('on');

      if (~isempty(stpfr))
         msg={['Drag the green lines in the plot to adjust ',...
              'the start of the steps.'],['Add lines by right clicking', ...
              ' in the figure. Remove lines by holding down ''shift''', ...
              ' while clicking.'],['Zoom by drawing over the region of ',...
              ' interest. Double-click to zoom back to original.'],...
              'Click ok when finished'};
      else
         msg={['Add lines by right clicking', ...
              ' in the figure. Remove lines by holding down ''shift''', ...
              ' while clicking.'],['Zoom by drawing over the region of ',...
              ' interest. Double-click to zoom back to original.'],...
              'Click ok when finished'};
      end

      msg=textwrap(msg,40);
      uiwait(msgbox(msg,'Instructions'));

      % Check the XData values of the steplines
      figure(fig)
      lines=get(gca,'Children');

      stepfr=[];
      for i=1:length(lines)
         if (get(lines(i),'ZData'))
            xd=get(lines(i),'XData');
            stepfr=[stepfr;xd(1)];
         end
      end

      stepfr=fix(stepfr);
      stepfr(find(stepfr<1))=[];
      
      stepfr=sort(stepfr);

      uiwait(msgbox({'Beginning of steps found at frame #',...
                     sprintf('%d  ',stepfr)},'Steps'))
