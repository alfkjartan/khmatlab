function openfiltergui(h)
% Simple function that launches the filter gui, and sets the
% UserData attribute of the filter figure to the handle h.
% This way, the functions of filter gui can easily reference
% the tsvpreprocgui, and its important tsvdata (UserData) attribute.

% Kjartan Halvorsen
% 2000-10-13

fh=filtergui;
set(fh,'UserData',h);

% Get handlers
txth=findobj(fh,'Tag','txt');

tsvd=get(h,'UserData');
samplefr=getvalue(tsvd.tsvattributes,'FREQUENCY');

set(txth,'String',['The sample frequency is ',samplefr,' Hz.']);

