function tsvppclose(h)
% Asks the user to save the data. Then closes the gui.

% Kjartan Halvorsen
% 2000-10-18

close(h)
