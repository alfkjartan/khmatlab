function segms=findrb(h)
%  segms=findrb(h)
% Searches the marker data for set of markers that might be parts
% of the same rigid body. Displays in the 'Detect rigid bodies' 
% dialog.

% Kjartan Halvorsen
% 2000-10-09

% get handles
tsvpph=get(h,'UserData');
sgmlh=findobj(h,'Tag','detectrbsgmlist');
mlh=findobj(h,'Tag','detectrbmlist');
slideh=findobj(h,'Tag','thrslider');

tsvdata=get(tsvpph,'UserData')
markernames=getvalue(tsvdata.tsvattributes,'MARKER_NAMES');
set(mlh,'UserData',markernames);

set(sgmlh,'String',{});

thr=get(slideh,'Value'); % Read the threshold value

sgms=detectrb(tsvdata.markerdata,thr*2);
set(sgmlh,'UserData',sgms);

sgmstr={};
for k=1:length(sgms)
   sgmstr{k}=['segment',int2str(k)];
end

if (~isempty(sgmstr)) 
   set(sgmlh,'String',sgmstr);
   set(sgmlh,'Value',1);
end

updatesgmlist(h);
