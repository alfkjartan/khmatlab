function movemarker(dir,h)
% Move selected marker up or down in the list of markers.
% Works only if a single marker is selected.
% dir=0 moves down the list, dir=1 moves up.

% Kjartan Halvorsen
% 2000-09-20

% Get handles
listh=findobj(h,'Tag','markerlist');
stath=findobj(h,'Tag','statusbar');

% Check the number of markers selected
nm=get(listh,'Value');

if (length(nm)>1)
   set(stath,'String','Only one marker can be moved at a time.');
else
   tsvdata=get(h,'UserData');
   md=tsvdata.markerdata;
   attr=tsvdata.tsvattributes;
   markernames=getvalue(attr,'MARKER_NAMES');
   marker=markernames{nm};
   if (dir==0)
      if (nm<length(markernames))
         [nmd,nattr]=moveseries(marker,'down',md,attr);
         set(stath,'String',['Marker ',marker,' moved down the list']);
         updatemarkerlist(listh,nattr,nm+1);
      else
         set(stath,'String','The marker is already at the bottom of the list.');
	 nmd=md;
	 nattr=attr;
      end
   else
      if (nm>1)
         [nmd,nattr]=moveseries(marker,'up',md,attr);
         set(stath,'String',['Marker ',marker,' moved up the list']);
         updatemarkerlist(listh,nattr,nm-1);
      else
         set(stath,'String','The marker is already at the top of the list.');
	 nmd=md;
	 nattr=attr;
      end
   end 

   tsvdata.markerdata=nmd;
   tsvdata.tsvattributes=nattr;
   set(h,'UserData',tsvdata);
   
   plotmarkers(h);
end      
